const wrapper = document.querySelector(".sliderWrapper")
const meniItems= document.querySelectorAll(".menuItem")
const categoryElements = document.querySelectorAll(".category");
const sizeElements = document.querySelectorAll(".size");

const product=[
{
    id: 1,
    title: "Mirror",
    price: 1500,
    color :[
        {
        code: "Irregular",
        img: "./img/m.png",
        },
        {
        code: "Square",
        img: "./img/square.png",
        },
        {
        code:"Round",
        img:"./img/round.png",
        },
    ],
    defaultImage: "./img/m.png",
},
{
    id: 2,
    title: "T-shirts",
    price: "1500",
    category:[
        {
        code:"black",
        img:"./img/t.png",
        },
        {
        code:"white",
        img:"./img/t 2.png",
        },
         {
        code:"grey",
        img:"./img/t 3.png",
        },
    ],

},
{
    id: 3,
    title: "Accessories",
    price: "500",
    category:[
        {
        code:"Green",
        img:"./img/acc 3.png",
        height: "30px" ,
        },
        {
        code:" Purple",
        img:"./img/acc 2.png",
        height: "30px" ,
        },
        {
        code:"Colorful",
        img:"./img/acc 4.png",
        height: "30px" ,
        },
    ],

},
{
    id: 4,
    title: "Jeans",
    price: "5000",
    category:[
        {
        code:"Black",
        img:"./img/jeans.png",
        },
        {
        code:"White",
        img:"./img/jeans 2.png",
        },
        {
        code:"Blue",
        img:"./img/jeans 3.png",
        },
    ],

},
{
    id: 5,
    title: "shoes",
    price: "2000",
    category:[
        {
        code:"Black",
        img:"./img/shose.png",
        },
        {
        code:"Off-White",
        img:"./img/shoes 2.png",
        },
        {
        code:"White",
        img:"./img/shoes 3.png",
        },  
    ],

},
{
    id: 6,
    title: "Tote bags",
    price: "1500",
    category:[
        {
        code:"White",
        img:"./img/tote.png",
        },
        {
        code:"Black",
        img:"./img/tote 2.png",
        },
        {
        code:"Grey",
        img:"./img/tote 3.png",
        },
    ],

},
];
let choosenProduct=product[0]

const currentProductImg = document.querySelector(".productImg")
const currentTitle = document.querySelector(".productTitle") 
const currentPrice = document.querySelector(".productprice") 
const currentCategories = document.querySelectorAll(".category") 
const currentProductSizes = document.querySelectorAll(".size")  
meniItems.forEach((item,index)=> {
    item.addEventListener("click",()=>{
        //change the current slide
        wrapper.style.transform= `translateX(${-100 *index}vw)`;
        //change the choosen product
        choosenProduct=product [index]
        //change texts of current product
        currentTitle.textContent= choosenProduct.title;
        currentPrice.textContent= "Rs. "+ choosenProduct.price;
        currentProductImg.src= choosenProduct.category[0].img;
        //Update category buttons based on the chosen product
        categoryElements.forEach((category,index)=>{
            category.textContent=choosenProduct.category[index].code;
        })
    });
});
// Add event listener for category selection
categoryElements.forEach((category, index) => {
    category.addEventListener("click", () => {
        const selectedCategory =category.textContent.toLowerCase(); // Corrected the toLowerCase call
        const selectedCategoryObject = choosenProduct.category.find(cat => cat.code.toLowerCase() === selectedCategory);
        
        console.log(`Selected Category: ${selectedCategory}`);
        
        let imagePath;
        if (selectedCategory === "square") {
            imagePath = "./img/square.png";
        } 
        else if (selectedCategory === "round") {
            imagePath = "./img/round.png";
        } 
        console.log(`Selected Category Image Path: ${imagePath}`);

        if (selectedCategoryObject) {
            // Update the product image with the selected category image
            currentProductImg.src = selectedCategoryObject.img;
        }
        
        currentCategories.forEach((categories, i) => {
categories.textContent = choosenProduct.category[i].code;
});
        if (choosenProduct.title === "Mirror") {
            // Handle categories for "Mirror"
            switch (selectedCategory) {
                case "irregular":
                    break;
                case "square":
                    break;
                case "round":
                    break;
                default:
                    break;
            }
        }
    else if(choosenProduct.title=="T-shirts"){
        switch(selectedCategory){
            case "Black":
                break;
            case "White":
                break;
            case "Grey":
            break;
            default:        
        }
        }
    else if(choosenProduct.title=="Jeans"){
        switch(selectedCategory){
            case "Black":
                break;
            case "White":
                break;
            case "Blue":
                break;
                default:        
            }
            }
    else if(choosenProduct.title=="Shoes"){
        switch(selectedCategory){
            case "Black":
                break;
            case "Off White":
                break;
            case "White":
                break;
                default:        
                }
        } 
    else if(choosenProduct.title=="Tote Bags"){
        switch(selectedCategory){
            case "White":
                break;
            case "Black":
                break;
            case "Green":
                break;
                default:        
            }
        }      
    });
});
const currentCategory = document.querySelectorAll(".category");
const currentSizes = document.querySelectorAll(".size");


categoryElements.forEach((category, index) => {
  category.addEventListener("click", () => {
    currentProductImg.src = choosenProduct.category[index].img;
  });
});

currentProductSizes.forEach((size,index)=>{
    size.addEventListener("click",()=>
    {
        currentProductSizes.forEach((size)=>
        {
        size.style.backgroundColor = "white"
        size.style.color='rgb(' + 171 + ',' + 111 + ',' + 74 + ')';
        size.style.border="1px solid white"
        }
        )
        size.style.backgroundColor = 'rgb(' + 171 + ',' + 111 + ',' + 74 + ')';
        size.style.color="white"
        size.style.border="1px solid white"
    });
});

const productButton= document.querySelector(".productButton");
const payment = document.querySelector(".payment");
const close=document.querySelector(".close");

productButton.addEventListener("click", ()=>{
    payment.style.display= "flex"
});
close.addEventListener("click", () => {
    payment.style.display = "none";
});